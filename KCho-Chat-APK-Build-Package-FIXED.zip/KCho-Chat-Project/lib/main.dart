import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'screens/auth_screen.dart';
import 'screens/home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  const url = String.fromEnvironment('SUPABASE_URL');
  const anonKey = String.fromEnvironment('SUPABASE_ANON_KEY');
  if (url.isEmpty || anonKey.isEmpty) {
    runApp(const SetupRequiredApp());
    return;
  }
  await Supabase.initialize(url: url, anonKey: anonKey);
  runApp(const KChoChatApp());
}

class KChoChatApp extends StatelessWidget {
  const KChoChatApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: "K'Cho Chat", debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF3867D6)), useMaterial3: true, scaffoldBackgroundColor: const Color(0xFFF6F7FB)),
    home: StreamBuilder<AuthState>(
      stream: Supabase.instance.client.auth.onAuthStateChange,
      builder: (context, snapshot) => Supabase.instance.client.auth.currentSession == null ? const AuthScreen() : const HomeScreen(),
    ),
  );
}

class SetupRequiredApp extends StatelessWidget {
  const SetupRequiredApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    home: Scaffold(body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: const [
      Icon(Icons.settings_suggest, size: 56), SizedBox(height: 16), Text('K’Cho Chat setup required', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), SizedBox(height: 12),
      Text('Start the app with your Supabase URL and anon key. See README.md for the beginner-friendly steps.', textAlign: TextAlign.center),
    ])))),
  );
}
