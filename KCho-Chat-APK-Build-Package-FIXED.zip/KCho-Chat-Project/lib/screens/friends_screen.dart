import 'package:flutter/material.dart';
import '../services/supabase_service.dart';
import 'chat_screen.dart';

class FriendsScreen extends StatefulWidget { const FriendsScreen({super.key}); @override State<FriendsScreen> createState() => _FriendsScreenState(); }
class _FriendsScreenState extends State<FriendsScreen> {
  final _search = TextEditingController(); Map<String,dynamic>? _found; bool _busy=false; late Future<List<Map<String,dynamic>>> _friends;
  @override void initState(){super.initState();_friends=SupabaseService.instance.friends();}
  @override void dispose(){_search.dispose();super.dispose();}
  void _refresh()=>setState(()=>_friends=SupabaseService.instance.friends());
  Future<void> _find() async { setState((){_busy=true;_found=null;}); try { final u=await SupabaseService.instance.findUser(_search.text); if(mounted)setState(()=>_found=u); } catch(e){_toast('$e');} if(mounted)setState(()=>_busy=false); }
  void _toast(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));
  Future<void> _add() async { if(_found==null)return; try{await SupabaseService.instance.sendRequest(_found!['id']);_toast('Friend request sent.');setState(()=>_found=null);}catch(e){_toast(e.toString().replaceFirst('Exception: ',''));} }
  @override Widget build(BuildContext context)=>RefreshIndicator(onRefresh:()async=>_refresh(),child:ListView(padding:const EdgeInsets.all(16),children:[
    TextField(controller:_search,textCapitalization:TextCapitalization.characters,decoration:InputDecoration(hintText:'Enter KCHO-XXXXXX',labelText:'Find a friend by K’Cho ID',prefixIcon:const Icon(Icons.search),suffixIcon:IconButton(onPressed:_busy?null:_find,icon:const Icon(Icons.arrow_forward)),border:const OutlineInputBorder()),onSubmitted:(_)=>_find()),
    if(_busy) const LinearProgressIndicator(), if(_found!=null) Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.person_add)),title:Text(_found!['display_name']??'K’Cho user'),subtitle:Text(_found!['kcho_id']??''),trailing:FilledButton(onPressed:_add,child:const Text('Add')))),
    const Padding(padding:EdgeInsets.only(top:24,bottom:8),child:Text('My friends',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold))),
    FutureBuilder<List<Map<String,dynamic>>>(future:_friends,builder:(context,s){if(s.connectionState==ConnectionState.waiting)return const Padding(padding:EdgeInsets.all(24),child:Center(child:CircularProgressIndicator()));if(s.hasError)return Text('Error: ${s.error}');final list=s.data??[];if(list.isEmpty)return const Padding(padding:EdgeInsets.all(24),child:Text('No friends yet. Search by K’Cho ID to send a request.',textAlign:TextAlign.center));return Column(children:list.map((u)=>ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text(u['display_name']??'K’Cho user'),subtitle:Text(u['kcho_id']??''),trailing:IconButton(icon:const Icon(Icons.chat_outlined),onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ChatScreen(user:u)))))).toList());})
  ]));
}
