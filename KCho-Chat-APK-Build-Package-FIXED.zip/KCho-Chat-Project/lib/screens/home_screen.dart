import 'package:flutter/material.dart';
import '../services/supabase_service.dart';
import 'chat_screen.dart';
import 'friends_screen.dart';
import 'requests_screen.dart';

class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState() => _HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0; Map<String,dynamic>? _profile;
  @override void initState() { super.initState(); _loadProfile(); }
  Future<void> _loadProfile() async { try { final p = await SupabaseService.instance.myProfile(); if (mounted) setState(() => _profile = p); } catch (_) {} }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text("K’Cho Chat", style: TextStyle(fontWeight: FontWeight.bold)), actions: [if (_profile != null) Padding(padding: const EdgeInsets.only(right: 8), child: Center(child: Text(_profile!['kcho_id'] ?? '', style: const TextStyle(fontWeight: FontWeight.w600)))), IconButton(tooltip: 'Sign out', onPressed: () => SupabaseService.instance.signOut(), icon: const Icon(Icons.logout))]),
    body: IndexedStack(index: _tab, children: [const FriendsScreen(), const RequestsScreen(), const _ChatsScreen()]),
    bottomNavigationBar: NavigationBar(selectedIndex: _tab, onDestinationSelected: (i) => setState(() => _tab = i), destinations: const [NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'Friends'), NavigationDestination(icon: Icon(Icons.person_add_alt), label: 'Requests'), NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'Chats')]),
  );
}
class _ChatsScreen extends StatefulWidget { const _ChatsScreen(); @override State<_ChatsScreen> createState() => _ChatsScreenState(); }
class _ChatsScreenState extends State<_ChatsScreen> {
  late Future<List<Map<String,dynamic>>> _future;
  @override void initState() { super.initState(); _future = SupabaseService.instance.chatPartners(); }
  void _refresh() => setState(() => _future = SupabaseService.instance.chatPartners());
  @override Widget build(BuildContext context) => RefreshIndicator(onRefresh: () async => _refresh(), child: FutureBuilder<List<Map<String,dynamic>>>(future: _future, builder: (context,s) {
    if (s.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
    if (s.hasError) return Center(child: Text('Could not load chats: ${s.error}'));
    final users = s.data ?? []; if (users.isEmpty) return ListView(children: const [SizedBox(height: 130), Icon(Icons.forum_outlined, size: 56, color: Colors.grey), SizedBox(height: 12), Center(child: Text('Your accepted friends will appear here.'))]);
    return ListView.separated(itemCount: users.length, separatorBuilder: (_,__) => const Divider(height: 1), itemBuilder: (context,i) { final u=users[i]; return ListTile(leading: const CircleAvatar(child: Icon(Icons.person)), title: Text(u['display_name'] ?? 'K’Cho user'), subtitle: Text(u['kcho_id'] ?? ''), trailing: const Icon(Icons.chevron_right), onTap: () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(user: u))); _refresh(); }); });
  }));
}
