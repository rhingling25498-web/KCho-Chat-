import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseService {
  SupabaseService._();
  static final SupabaseService instance = SupabaseService._();
  SupabaseClient get db => Supabase.instance.client;
  String get uid => db.auth.currentUser!.id;

  Future<void> signUp(String email, String password, String name) async {
    final result = await db.auth.signUp(email: email, password: password, data: {'display_name': name});
    if (result.user == null) throw Exception('Account could not be created.');
  }
  Future<void> signIn(String email, String password) => db.auth.signInWithPassword(email: email, password: password);
  Future<void> signOut() => db.auth.signOut();
  Future<Map<String, dynamic>> myProfile() async => await db.from('profiles').select().eq('id', uid).single();

  Future<List<Map<String, dynamic>>> friends() async {
    final rows = await db.from('friendships').select('user_one,user_two').or('user_one.eq.$uid,user_two.eq.$uid');
    final ids = (rows as List).map((r) => r['user_one'] == uid ? r['user_two'] : r['user_one']).cast<String>().toList();
    if (ids.isEmpty) return [];
    return List<Map<String, dynamic>>.from(await db.from('profiles').select().inFilter('id', ids).order('display_name'));
  }
  Future<List<Map<String, dynamic>>> incomingRequests() async => List<Map<String, dynamic>>.from(
    await db.from('friend_requests').select('id,created_at,sender:profiles!friend_requests_sender_id_fkey(id,display_name,kcho_id)').eq('receiver_id', uid).eq('status', 'pending').order('created_at', ascending: false));
  Future<List<Map<String, dynamic>>> outgoingRequests() async => List<Map<String, dynamic>>.from(
    await db.from('friend_requests').select('id,created_at,receiver:profiles!friend_requests_receiver_id_fkey(id,display_name,kcho_id)').eq('sender_id', uid).eq('status', 'pending'));
  Future<Map<String, dynamic>?> findUser(String kchoId) async {
    final rows = await db.from('profiles').select('id,display_name,kcho_id').eq('kcho_id', kchoId.trim().toUpperCase()).limit(1);
    return rows.isEmpty ? null : Map<String, dynamic>.from(rows.first);
  }
  Future<void> sendRequest(String targetId) async {
    if (targetId == uid) throw Exception('You cannot add yourself.');
    await db.from('friend_requests').insert({'sender_id': uid, 'receiver_id': targetId});
  }
  Future<void> respondRequest(String requestId, String status) async {
    await db.from('friend_requests').update({'status': status}).eq('id', requestId).eq('receiver_id', uid).eq('status', 'pending');
  }
  Future<List<Map<String, dynamic>>> chatPartners() async => friends();
  Future<List<Map<String, dynamic>>> messages(String otherId) async => List<Map<String, dynamic>>.from(
    await db.from('messages').select().or('and(sender_id.eq.$uid,receiver_id.eq.$otherId),and(sender_id.eq.$otherId,receiver_id.eq.$uid)').order('created_at'));
  Future<void> sendMessage(String otherId, String body) async {
    final text = body.trim(); if (text.isEmpty) return;
    await db.from('messages').insert({'sender_id': uid, 'receiver_id': otherId, 'body': text});
  }
  Stream<List<Map<String, dynamic>>> watchMessages(String otherId) => db.from('messages').stream(primaryKey: ['id']).order('created_at').map((rows) => rows.where((m) => (m['sender_id'] == uid && m['receiver_id'] == otherId) || (m['sender_id'] == otherId && m['receiver_id'] == uid)).toList());
  Stream<List<Map<String, dynamic>>> watchRequests() => db.from('friend_requests').stream(primaryKey: ['id']).eq('receiver_id', uid).map((rows) => rows.where((r) => r['status'] == 'pending').toList());
}
