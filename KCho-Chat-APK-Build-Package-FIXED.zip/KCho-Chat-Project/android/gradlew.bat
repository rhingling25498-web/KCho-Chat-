@echo off
setlocal
set GRADLE_VERSION=9.3.1
set GRADLE_HOME_DIR=%USERPROFILE%\.gradle\kcho-wrapper\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME_DIR%\bin\gradle.bat" (
  if not exist "%USERPROFILE%\.gradle\kcho-wrapper" mkdir "%USERPROFILE%\.gradle\kcho-wrapper"
  powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-all.zip' -OutFile '%USERPROFILE%\.gradle\kcho-wrapper\gradle-%GRADLE_VERSION%-all.zip'"
  powershell -NoProfile -Command "Expand-Archive -Force '%USERPROFILE%\.gradle\kcho-wrapper\gradle-%GRADLE_VERSION%-all.zip' '%USERPROFILE%\.gradle\kcho-wrapper'"
)
call "%GRADLE_HOME_DIR%\bin\gradle.bat" %*
