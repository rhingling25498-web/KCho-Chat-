package com.kcho.chat

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
