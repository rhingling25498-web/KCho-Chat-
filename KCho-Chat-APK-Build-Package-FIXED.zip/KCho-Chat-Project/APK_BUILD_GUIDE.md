# APK build quick guide (GitHub Actions is intentionally not included)

## Repository root must look like this

```text
repository-root/
  android/
  lib/
  pubspec.yaml
  analysis_options.yaml
  supabase_schema.sql
  README.md
```

Do not leave all files nested inside another folder, and do not upload only the ZIP archive. Extract it and upload the extracted project contents to the repository root.

## GitHub repository secrets

Add `SUPABASE_URL` and `SUPABASE_ANON_KEY` in Settings → Secrets and variables → Actions. Use the public anon/publishable key only; never use `service_role`.

## Build command for your own workflow

```bash
flutter pub get
flutter analyze
flutter build apk --release \
  --dart-define=SUPABASE_URL=${{ secrets.SUPABASE_URL }} \
  --dart-define=SUPABASE_ANON_KEY=${{ secrets.SUPABASE_ANON_KEY }}
```

Use Ubuntu, Flutter stable, and Java 17. Upload `build/app/outputs/flutter-apk/app-release.apk` as the workflow artifact. No Actions YAML is included in this ZIP.
