-- K'Cho Chat schema. Run in Supabase SQL Editor in a fresh project.
-- If you already created tables, compare names/columns before running this file.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'K’Cho user',
  kcho_id text unique,
  created_at timestamptz not null default now(),
  constraint profiles_kcho_id_format check (kcho_id is null or kcho_id ~ '^KCHO-[A-F0-9]{6}$')
);

-- Users may update their display name, but never their auth ID or assigned K'Cho ID.
create or replace function public.protect_profile_identity()
returns trigger language plpgsql as $$
begin
  if new.id is distinct from old.id or new.kcho_id is distinct from old.kcho_id then
    raise exception 'Profile ID and K’Cho ID cannot be changed';
  end if;
  return new;
end; $$;
drop trigger if exists protect_profile_identity_before_update on public.profiles;
create trigger protect_profile_identity_before_update
before update on public.profiles for each row execute procedure public.protect_profile_identity();

create or replace function public.make_kcho_id()
returns text language plpgsql as $$
declare candidate text;
begin
  loop
    candidate := 'KCHO-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6));
    exit when not exists (select 1 from public.profiles where kcho_id = candidate);
  end loop;
  return candidate;
end; $$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id,display_name,kcho_id)
  values(new.id,coalesce(new.raw_user_meta_data->>'display_name','K’Cho user'),public.make_kcho_id())
  on conflict (id) do nothing;
  return new;
end; $$;

drop trigger if exists on_auth_user_created_kcho on auth.users;
create trigger on_auth_user_created_kcho after insert on auth.users
for each row execute procedure public.handle_new_user();

create table if not exists public.friend_requests (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check(status in ('pending','accepted','rejected')),
  created_at timestamptz not null default now(),
  responded_at timestamptz,
  check(sender_id <> receiver_id)
);
create unique index if not exists friend_requests_one_pending_pair
on public.friend_requests(least(sender_id,receiver_id), greatest(sender_id,receiver_id))
where status = 'pending';

create or replace function public.reject_request_between_existing_friends()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if exists (
    select 1 from public.friendships f
    where f.user_one = least(new.sender_id,new.receiver_id)
      and f.user_two = greatest(new.sender_id,new.receiver_id)
  ) then
    raise exception 'You are already friends';
  end if;
  return new;
end; $$;
drop trigger if exists friend_request_check_existing_friendship on public.friend_requests;
create trigger friend_request_check_existing_friendship
before insert on public.friend_requests for each row
execute procedure public.reject_request_between_existing_friends();

create table if not exists public.friendships (
  user_one uuid not null references public.profiles(id) on delete cascade,
  user_two uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_one,user_two),
  check(user_one < user_two)
);

create or replace function public.record_friendship_on_accept()
returns trigger language plpgsql security definer set search_path = public as $$
declare a uuid; b uuid;
begin
  if new.sender_id <> old.sender_id or new.receiver_id <> old.receiver_id then
    raise exception 'Friend request participants cannot be changed';
  end if;
  if old.status <> 'pending' or new.status not in ('accepted','rejected') then
    raise exception 'Only pending requests can be accepted or rejected';
  end if;
  if new.status = 'accepted' and old.status = 'pending' then
    a := least(new.sender_id,new.receiver_id); b := greatest(new.sender_id,new.receiver_id);
    insert into public.friendships(user_one,user_two) values(a,b) on conflict do nothing;
    new.responded_at := now();
  elsif new.status in ('rejected') and old.status = 'pending' then
    new.responded_at := now();
  end if;
  return new;
end; $$;
drop trigger if exists friend_request_response on public.friend_requests;
create trigger friend_request_response before update on public.friend_requests
for each row execute procedure public.record_friendship_on_accept();

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check(length(trim(body)) > 0),
  created_at timestamptz not null default now(),
  check(sender_id <> receiver_id)
);
create index if not exists messages_conversation_time on public.messages(sender_id,receiver_id,created_at);

alter table public.profiles enable row level security;
alter table public.friend_requests enable row level security;
alter table public.friendships enable row level security;
alter table public.messages enable row level security;

drop policy if exists "profiles authenticated can read" on public.profiles;
create policy "profiles authenticated can read" on public.profiles for select to authenticated using (true);
drop policy if exists "profile owner can update" on public.profiles;
create policy "profile owner can update" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "request participants can read" on public.friend_requests;
create policy "request participants can read" on public.friend_requests for select to authenticated using (auth.uid() = sender_id or auth.uid() = receiver_id);
drop policy if exists "users can send requests" on public.friend_requests;
create policy "users can send requests" on public.friend_requests for insert to authenticated with check (auth.uid() = sender_id and status = 'pending');
drop policy if exists "receiver can respond" on public.friend_requests;
create policy "receiver can respond" on public.friend_requests for update to authenticated using (auth.uid() = receiver_id and status = 'pending') with check (auth.uid() = receiver_id and status in ('accepted','rejected'));

drop policy if exists "friends can read friendship" on public.friendships;
create policy "friends can read friendship" on public.friendships for select to authenticated using (auth.uid() = user_one or auth.uid() = user_two);

drop policy if exists "friends can read messages" on public.messages;
create policy "friends can read messages" on public.messages for select to authenticated using (
  (auth.uid() = sender_id or auth.uid() = receiver_id) and exists (
    select 1 from public.friendships f where f.user_one = least(sender_id,receiver_id) and f.user_two = greatest(sender_id,receiver_id)
  )
);
drop policy if exists "friends can send messages" on public.messages;
create policy "friends can send messages" on public.messages for insert to authenticated with check (
  auth.uid() = sender_id and exists (
    select 1 from public.friendships f where f.user_one = least(sender_id,receiver_id) and f.user_two = greatest(sender_id,receiver_id)
  )
);

-- Enable Realtime for live chat updates (ignore duplicate publication membership errors).
do $$ begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null; when others then null;
end $$;
