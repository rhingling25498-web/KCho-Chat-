# K’Cho Chat — Android APK build package

This is the Flutter Android source project for K’Cho Chat. It includes the Dart app, Android Gradle configuration, Gradle launcher scripts, Supabase SQL schema, and build instructions. **There is intentionally no `.github/workflows/` folder and no GitHub Actions workflow**; create your own workflow in GitHub as requested.

> Build status: this archive has been checked for required source/config files and ZIP integrity. It has **not** been compiled into an APK in this environment because Flutter and Android SDK are not installed here. A successful APK build still needs your Supabase project settings and a GitHub Actions run.

## What is included

- `lib/` — Flutter screens and Supabase service
- `android/` — Android app manifest, Kotlin entry point, Gradle configuration and launch scripts
- `supabase_schema.sql` — database tables, KCHO ID generator, friend request/friendship triggers, RLS policies and Realtime publication setup
- `APK_BUILD_GUIDE.md` — step-by-step GitHub upload and APK build notes
- `pubspec.yaml` — Flutter package dependencies

## 1. Configure Supabase first

1. Open your Supabase project → **SQL Editor**.
2. If this is a brand-new/empty database, run the full `supabase_schema.sql` file once.
3. If you already created tables with earlier SQL, **do not blindly run this file**. Compare the existing schema first; this app expects the tables and columns below.
4. In **Project Settings → API**, copy the Project URL and the public `anon` / publishable key.
5. In **Authentication → Providers → Email**, enable Email/Password sign-in. Choose whether email confirmation is required. For production, keep confirmation enabled and configure email delivery.
6. Ensure `messages` is enabled in the `supabase_realtime` publication if live message updates are not delivered.

The Flutter app uses only the public anon/publishable key. **Never put the Supabase `service_role` key or a secret key in Flutter, GitHub repository files, or APK build variables.** The anon key is intended for client apps; database safety depends on the RLS policies.

Expected schema:

- `profiles(id, display_name, kcho_id, created_at)`
- `friend_requests(id, sender_id, receiver_id, status, created_at, responded_at)`
- `friendships(user_one, user_two, created_at)`
- `messages(id, sender_id, receiver_id, body, created_at)`

`profiles` intentionally does not expose email addresses to other users. User search uses the exact `KCHO-XXXXXX` ID.

## 2. Upload the project to GitHub

**Important: Extract the ZIP first. Do not upload only the ZIP file if you want GitHub Actions to build the app.**

1. Download and extract `KCho-Chat-Project.zip` on your computer.
2. Open your GitHub repository.
3. Upload the *contents inside* the `KCho-Chat-Project` folder to the repository root. The repository root should directly show `pubspec.yaml`, `lib/`, `android/`, `supabase_schema.sql`, and `README.md`.
4. Do not create or upload a `.github/workflows/` file from this package. You said you will create GitHub Actions yourself.

## 3. Build locally (optional)

Install Flutter stable, Android Studio/Android SDK and Java 17. Run these commands from the repository root:

```bash
flutter doctor
flutter pub get
flutter analyze
flutter build apk --release \
  --dart-define=SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
```

This starter signs the release APK with the Android debug key so it can be installed for testing. Before publishing to Google Play or distributing a production release, configure your own private release keystore and keep its passwords out of source control.

The APK output is:

```text
build/app/outputs/flutter-apk/app-release.apk
```

The included `android/gradlew` and `android/gradlew.bat` scripts download the pinned Gradle 9.3.1 distribution on first use. The Android Gradle Plugin is pinned to 9.1.1 and Kotlin Gradle Plugin to 2.2.10; legacy Kotlin and DSL compatibility flags are enabled for Flutter migration. A working internet connection is required on the first Gradle run. Flutter's `flutter pub get` generates the machine-specific `android/local.properties`; do not commit that file.

## 4. GitHub Actions build settings (you create the workflow)

In your GitHub repository, add these under **Settings → Secrets and variables → Actions**:

- `SUPABASE_URL` — your Supabase Project URL
- `SUPABASE_ANON_KEY` — your Supabase public anon/publishable key

In your own workflow, the important build command is:

```bash
flutter pub get
flutter build apk --release \
  --dart-define=SUPABASE_URL=${{ secrets.SUPABASE_URL }} \
  --dart-define=SUPABASE_ANON_KEY=${{ secrets.SUPABASE_ANON_KEY }}
```

Use a GitHub-hosted Ubuntu runner with Flutter stable and Java 17. After the build, upload this path as a workflow artifact:

```text
build/app/outputs/flutter-apk/app-release.apk
```

This ZIP does not contain a workflow YAML because you asked to write GitHub Actions yourself.

## App functions

1. Register / log in with email and password.
2. The database trigger creates a unique `KCHO-XXXXXX` ID for each new account.
3. Search another user by K’Cho ID and send a friend request.
4. The receiver accepts or rejects the request.
5. Accepting creates a friendship record.
6. Only accepted friends can read or send direct messages; chat history and Realtime updates are shown in the app.

## Important limitations

This is a functional starter implementation, not a production-audited messenger. Password reset, profile images, push notifications, typing status, read receipts, blocking/reporting, and end-to-end encryption are not included. Test signup, friend requests, and chat with two separate accounts before sharing the APK. Keep RLS enabled.
