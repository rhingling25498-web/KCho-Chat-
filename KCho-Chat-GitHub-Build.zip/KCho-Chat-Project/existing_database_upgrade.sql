-- K'Cho Chat upgrade for the EXISTING database described by the owner.
-- Existing profiles: id, user_code, display_name, created_at
-- Existing chats/friendships: id, user_one, user_two, created_at
-- Existing messages: id, chat_id, sender_id, message_text, created_at, media_url, media_type
-- Existing user_presence: user_id, is_online, last_seen
-- Does not drop tables or change the existing chat-media bucket's PRIVATE setting or size limit.

begin;

-- Add only the fields used by the current app. These are safe if already present.
alter table public.profiles add column if not exists avatar_url text;

-- Preserve the existing user_code field and generate KCHO-XXXXXX values when absent.
create or replace function public.make_kcho_user_code()
returns text language plpgsql as $$
declare candidate text;
begin
  loop
    candidate := 'KCHO-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6));
    exit when not exists (select 1 from public.profiles where user_code = candidate);
  end loop;
  return candidate;
end; $$;
create unique index if not exists profiles_user_code_unique on public.profiles(user_code) where user_code is not null;
create or replace function public.fill_profile_user_code()
returns trigger language plpgsql as $$
begin
  if new.user_code is null or btrim(new.user_code) = '' then
    new.user_code := public.make_kcho_user_code();
  end if;
  return new;
end; $$;
drop trigger if exists fill_profile_user_code_before_insert on public.profiles;
create trigger fill_profile_user_code_before_insert before insert on public.profiles
for each row execute function public.fill_profile_user_code();
update public.profiles set user_code = public.make_kcho_user_code() where user_code is null or btrim(user_code) = '';

create or replace function public.create_profile_for_new_auth_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, user_code, display_name)
  values (new.id, public.make_kcho_user_code(), coalesce(new.raw_user_meta_data->>'display_name', 'K’Cho user'))
  on conflict (id) do nothing;
  return new;
end; $$;
drop trigger if exists on_auth_user_created_kcho on auth.users;
drop trigger if exists protect_profile_identity_before_update on public.profiles;
drop trigger if exists create_profile_for_new_auth_user_trigger on auth.users;
create trigger create_profile_for_new_auth_user_trigger after insert on auth.users
for each row execute function public.create_profile_for_new_auth_user();

alter table public.messages add column if not exists receiver_id uuid references public.profiles(id) on delete cascade;
alter table public.messages add column if not exists read_at timestamptz;

create index if not exists idx_messages_chat_created_at on public.messages(chat_id, created_at);
create index if not exists idx_messages_receiver_read on public.messages(receiver_id, read_at);

-- Backfill receiver_id from the existing chats table wherever possible.
update public.messages m
set receiver_id = case
  when c.user_one = m.sender_id then c.user_two
  when c.user_two = m.sender_id then c.user_one
  else null
end
from public.chats c
where m.chat_id = c.id and m.receiver_id is null;

-- Keep the chat-media bucket private. Do not overwrite file_size_limit (NULL stays NULL).
insert into storage.buckets (id, name, public)
values ('chat-media', 'chat-media', false)
on conflict (id) do nothing;

drop policy if exists "chat media upload own folder" on storage.objects;
create policy "chat media upload own folder"
on storage.objects for insert to authenticated
with check (bucket_id = 'chat-media' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "chat media friends can read" on storage.objects;
create policy "chat media friends can read"
on storage.objects for select to authenticated
using (
  bucket_id = 'chat-media'
  and (
    (storage.foldername(name))[1] = auth.uid()::text
    or exists (
      select 1 from public.friendships f
      where (f.user_one::text = (storage.foldername(name))[1] and f.user_two = auth.uid())
         or (f.user_two::text = (storage.foldername(name))[1] and f.user_one = auth.uid())
    )
  )
);

-- Avatars remain a separate public bucket for profile pictures.
insert into storage.buckets (id, name, public)
values ('avatars', 'avatars', true)
on conflict (id) do update set public = true;
drop policy if exists "Avatar images are publicly readable" on storage.objects;
create policy "Avatar images are publicly readable" on storage.objects
for select to public using (bucket_id = 'avatars');
drop policy if exists "Users can upload their own avatar" on storage.objects;
create policy "Users can upload their own avatar" on storage.objects
for insert to authenticated with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "Users can update their own avatar" on storage.objects;
create policy "Users can update their own avatar" on storage.objects
for update to authenticated using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text)
with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

-- Required SQL privileges for the authenticated Flutter client.
grant select, update on public.profiles to authenticated;
grant select on public.friendships to authenticated;
grant select, insert, update on public.friend_requests to authenticated;
grant select, insert on public.chats to authenticated;
grant select, insert, delete on public.messages to authenticated;
grant select, insert, update on public.user_presence to authenticated;

-- Typing indicator table used by the app.
create table if not exists public.chat_typing (
  user_id uuid not null references auth.users(id) on delete cascade,
  partner_id uuid not null references auth.users(id) on delete cascade,
  is_typing boolean not null default true,
  updated_at timestamptz not null default now(),
  primary key (user_id, partner_id),
  constraint chat_typing_not_self check (user_id <> partner_id)
);
alter table public.chat_typing enable row level security;
grant select, insert, update, delete on public.chat_typing to authenticated;
drop policy if exists "chat participants can view typing" on public.chat_typing;
create policy "chat participants can view typing" on public.chat_typing for select to authenticated
using (auth.uid() = user_id or auth.uid() = partner_id);
drop policy if exists "users insert own typing" on public.chat_typing;
create policy "users insert own typing" on public.chat_typing for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "users update own typing" on public.chat_typing;
create policy "users update own typing" on public.chat_typing for update to authenticated
using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "users delete own typing" on public.chat_typing;
create policy "users delete own typing" on public.chat_typing for delete to authenticated using (auth.uid() = user_id);

-- Chat rows can be read/created only by the two accepted friends.
alter table public.chats enable row level security;
drop policy if exists "KCho chat participants read" on public.chats;
create policy "KCho chat participants read" on public.chats for select to authenticated
using (auth.uid() = user_one or auth.uid() = user_two);
drop policy if exists "KCho friends create chat" on public.chats;
create policy "KCho friends create chat" on public.chats for insert to authenticated
with check (
  (auth.uid() = user_one or auth.uid() = user_two)
  and exists (
    select 1 from public.friendships f
    where (f.user_one = public.chats.user_one and f.user_two = public.chats.user_two)
       or (f.user_one = public.chats.user_two and f.user_two = public.chats.user_one)
  )
);

-- Replace the two existing message read/send policies with policies matching chat_id.
alter table public.messages enable row level security;
drop policy if exists "Chat members can read messages" on public.messages;
drop policy if exists "Chat members can send messages" on public.messages;
drop policy if exists "KCho chat members read messages" on public.messages;
drop policy if exists "KCho friends send chat messages" on public.messages;
create policy "KCho chat members read messages" on public.messages for select to authenticated
using (
  (auth.uid() = sender_id or auth.uid() = receiver_id)
  and exists (
    select 1 from public.chats c where c.id = chat_id
      and ((c.user_one = sender_id and c.user_two = receiver_id)
        or (c.user_two = sender_id and c.user_one = receiver_id))
  )
  and exists (
    select 1 from public.friendships f
    where (f.user_one = sender_id and f.user_two = receiver_id)
       or (f.user_one = receiver_id and f.user_two = sender_id)
  )
);
create policy "KCho friends send chat messages" on public.messages for insert to authenticated
with check (
  auth.uid() = sender_id and receiver_id is not null
  and exists (
    select 1 from public.chats c where c.id = chat_id
      and ((c.user_one = sender_id and c.user_two = receiver_id)
        or (c.user_two = sender_id and c.user_one = receiver_id))
  )
  and exists (
    select 1 from public.friendships f
    where (f.user_one = sender_id and f.user_two = receiver_id)
       or (f.user_one = receiver_id and f.user_two = sender_id)
  )
);

-- Receiver may only update read_at on messages addressed to them.
revoke update on public.messages from authenticated;
grant update (read_at) on public.messages to authenticated;
drop policy if exists "KCho receiver marks messages read" on public.messages;
create policy "KCho receiver marks messages read" on public.messages for update to authenticated
using (auth.uid() = receiver_id)
with check (auth.uid() = receiver_id);

-- Realtime publication membership checks avoid duplicate-table errors.
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='messages') then
    alter publication supabase_realtime add table public.messages;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='user_presence') then
    alter publication supabase_realtime add table public.user_presence;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='chat_typing') then
    alter publication supabase_realtime add table public.chat_typing;
  end if;
end $$;

commit;
