# K’Cho Chat — existing Supabase database build package

This ZIP is prepared for the EXISTING K’Cho Chat database, not for a new/empty Supabase project.

## Database shape this app targets

- `profiles`: `id`, `user_code`, `display_name`, `created_at` (the upgrade adds `avatar_url`)
- `chats`: `id`, `user_one`, `user_two`, `created_at`
- `friendships`: `id`, `user_one`, `user_two`, `created_at`
- `messages`: `id`, `chat_id`, `sender_id`, `message_text`, `created_at`, `media_url`, `media_type` (the upgrade adds `receiver_id`, `read_at`)
- `user_presence`: `user_id`, `is_online`, `last_seen`
- Storage bucket `chat-media`: PRIVATE. The upgrade deliberately leaves `public=false` and does not change `file_size_limit`.

## One-time Supabase step

1. Open Supabase → SQL Editor.
2. Open `existing_database_upgrade.sql` from this ZIP and run it once.
3. Do not run the old/new-project schema setup scripts on this existing database. This package intentionally includes only the migration for the existing column names.
4. Keep the `chat-media` bucket private. The app stores object paths and obtains signed URLs for viewing media. The SQL allows only the owner and their accepted friend to read the object's path.

The migration is additive; it does not drop your tables or change the existing `chat-media` bucket's privacy or size limit. It creates/updates the `user_code` generator and profile signup trigger, adds avatar support, creates the typing table, and aligns chat/message/storage policies with `user_one`, `user_two`, `chat_id`, and `message_text`.

## GitHub Actions APK build

The included workflow can build either:
- the Flutter project files placed directly at repository root, or
- this ZIP uploaded to the repository root (the workflow extracts it and finds `pubspec.yaml`).

GitHub → Settings → Secrets and variables → Actions must contain:
- `SUPABASE_URL` = your Supabase project URL
- `SUPABASE_ANON_KEY` = your Supabase anon/publishable key

Never use the `service_role` key in the app or GitHub build secrets.

Then open GitHub → Actions → **Build KCho Chat APK** → Run workflow. On success, open the run and download artifact **KCho-Chat-APK**.

If the repository does not already have a workflow at `.github/workflows/build-apk.yml`, copy the workflow from this ZIP to that path and commit it first. A workflow stored only inside an unextracted ZIP is not activated by GitHub Actions.

## Included app behavior

- Email/password signup and login; generated `KCHO-XXXXXX` `user_code`.
- Friend search by K’Cho ID, send/accept/reject requests, friend list.
- Four bottom tabs: Friend, Chat, Request, Profile.
- Text, photo, video and recorded voice messages using existing `chat_id` and `message_text` columns.
- Realtime chat stream, read receipts, online/offline presence, typing indicator.
- Private `chat-media` storage access through signed URLs.
- Profile name and photo editing; password-reset email request.

## Not yet complete

- Voice/video calling buttons are placeholders; actual WebRTC/calling signaling is not connected.
- Push notifications require Firebase configuration and a trusted server/Edge Function.
- End-to-end encryption is not implemented.
- Password reset email can be requested, but the in-app recovery deep-link/new-password screen is not complete.
- Video upload size remains subject to Supabase project limits, network conditions, and the bucket's current configured limit. `file_size_limit = NULL` is not a guarantee of unlimited uploads.

## Build verification

The ZIP structure and source files were checked, but this environment has no Flutter SDK/Android SDK, so `flutter analyze` and APK compilation were not run here. GitHub Actions is the build verification step; if it fails, share the failed log (remove secrets first).
