# APK build

See README.md. This workflow supports a ZIP uploaded at repository root or the Flutter project files uploaded directly at repository root. Configure `SUPABASE_URL` and `SUPABASE_ANON_KEY` as GitHub Actions secrets, then run **Build KCho Chat APK** from Actions.
