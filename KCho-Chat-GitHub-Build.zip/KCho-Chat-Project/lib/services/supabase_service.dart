import 'dart:typed_data';
import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseService {
  SupabaseService._();
  static final SupabaseService instance = SupabaseService._();
  SupabaseClient get db => Supabase.instance.client;
  String get uid => db.auth.currentUser!.id;

  Future<void> signUp(String email, String password, String name) async {
    final result = await db.auth.signUp(email: email, password: password, data: {'display_name': name});
    if (result.user == null) throw Exception('Account could not be created.');
  }
  Future<void> signIn(String email, String password) => db.auth.signInWithPassword(email: email, password: password);
  Future<void> sendPasswordReset(String email) async {
    final cleanEmail = email.trim();
    if (cleanEmail.isEmpty || !cleanEmail.contains('@')) throw Exception('Please enter a valid email address.');
    await db.auth.resetPasswordForEmail(cleanEmail);
  }
  Future<void> signOut() => db.auth.signOut();
  Future<Map<String, dynamic>> myProfile() async => await db.from('profiles').select().eq('id', uid).single();

  Future<void> updateDisplayName(String name) async {
    final cleanName = name.trim();
    if (cleanName.isEmpty) throw Exception('Please enter your name.');
    await db.from('profiles').update({'display_name': cleanName}).eq('id', uid);
    await db.auth.updateUser(UserAttributes(data: {'display_name': cleanName}));
  }

  Future<String> uploadAvatar(Uint8List bytes, String extension) async {
    final ext = extension.toLowerCase().replaceAll('.', '');
    final path = '$uid/avatar_${DateTime.now().millisecondsSinceEpoch}.$ext';
    await db.storage.from('avatars').uploadBinary(path, bytes,
      fileOptions: FileOptions(contentType: ext == 'png' ? 'image/png' : 'image/jpeg', upsert: true));
    final url = db.storage.from('avatars').getPublicUrl(path);
    await db.from('profiles').update({'avatar_url': url}).eq('id', uid);
    return url;
  }

  Future<String> uploadChatMedia(Uint8List bytes, String extension, {required String contentType}) async {
    final ext = extension.toLowerCase().replaceAll('.', '');
    final path = '$uid/${DateTime.now().millisecondsSinceEpoch}_${DateTime.now().microsecondsSinceEpoch}.$ext';
    await db.storage.from('chat-media').uploadBinary(path, bytes,
      fileOptions: FileOptions(contentType: contentType, upsert: false));
    // Store the object path, not a public URL. The bucket remains private.
    return path;
  }

  Future<String> chatMediaSignedUrl(String path) => db.storage.from('chat-media').createSignedUrl(path, 3600);

  Future<String> _ensureChat(String otherId) async {
    final rows = await db.from('chats').select('id')
      .or('and(user_one.eq.$uid,user_two.eq.$otherId),and(user_one.eq.$otherId,user_two.eq.$uid)').limit(1);
    if (rows.isNotEmpty) return rows.first['id'] as String;
    final first = uid.compareTo(otherId) < 0 ? uid : otherId;
    final second = uid.compareTo(otherId) < 0 ? otherId : uid;
    final inserted = await db.from('chats').insert({'user_one': first, 'user_two': second}).select('id').single();
    return inserted['id'] as String;
  }

  Future<void> sendMediaMessage(String otherId, String mediaPath, String mediaType, {String caption = ''}) async {
    final chatId = await _ensureChat(otherId);
    await db.from('messages').insert({
      'chat_id': chatId, 'sender_id': uid, 'receiver_id': otherId,
      'message_text': caption.trim().isEmpty ? (mediaType == 'image' ? 'Photo' : 'Video') : caption.trim(), 'media_url': mediaPath, 'media_type': mediaType,
    });
  }

  Future<void> sendVoiceMessage(String otherId, String mediaPath, {int? durationMs}) async {
    final chatId = await _ensureChat(otherId);
    await db.from('messages').insert({
      'chat_id': chatId, 'sender_id': uid, 'receiver_id': otherId,
      'message_text': 'Voice message', 'media_url': mediaPath, 'media_type': 'voice',
    });
  }

  Future<void> markMessagesRead(String otherId) async {
    final chatId = await _ensureChat(otherId);
    await db.from('messages').update({'read_at': DateTime.now().toUtc().toIso8601String()})
      .eq('chat_id', chatId).eq('receiver_id', uid).isFilter('read_at', null);
  }

  Future<void> updateMyPresence(bool online) async {
    await db.from('user_presence').upsert({'user_id': uid, 'is_online': online,
      'last_seen': DateTime.now().toUtc().toIso8601String()}, onConflict: 'user_id');
  }
  Stream<List<Map<String, dynamic>>> watchPresence(String userId) =>
      db.from('user_presence').stream(primaryKey: ['user_id']).eq('user_id', userId);

  Future<void> updateTyping(String partnerId, bool typing) async {
    if (typing) {
      await db.from('chat_typing').upsert({'user_id': uid, 'partner_id': partnerId,
        'is_typing': true, 'updated_at': DateTime.now().toUtc().toIso8601String()}, onConflict: 'user_id,partner_id');
    } else {
      await db.from('chat_typing').delete().eq('user_id', uid).eq('partner_id', partnerId);
    }
  }
  Stream<List<Map<String, dynamic>>> watchTyping(String otherId) =>
      db.from('chat_typing').stream(primaryKey: ['user_id', 'partner_id']).eq('user_id', otherId).eq('partner_id', uid);

  Future<List<Map<String, dynamic>>> friends() async {
    final rows = await db.from('friendships').select('user_one,user_two').or('user_one.eq.$uid,user_two.eq.$uid');
    final ids = (rows as List).map((r) => r['user_one'] == uid ? r['user_two'] : r['user_one']).cast<String>().toList();
    if (ids.isEmpty) return [];
    return List<Map<String, dynamic>>.from(await db.from('profiles').select().inFilter('id', ids).order('display_name'));
  }
  Future<List<Map<String, dynamic>>> incomingRequests() async => List<Map<String, dynamic>>.from(
    await db.from('friend_requests').select('id,created_at,sender:profiles!friend_requests_sender_id_fkey(id,display_name,user_code)').eq('receiver_id', uid).eq('status', 'pending').order('created_at', ascending: false));
  Future<List<Map<String, dynamic>>> outgoingRequests() async => List<Map<String, dynamic>>.from(
    await db.from('friend_requests').select('id,created_at,receiver:profiles!friend_requests_receiver_id_fkey(id,display_name,user_code)').eq('sender_id', uid).eq('status', 'pending'));
  Future<Map<String, dynamic>?> findUser(String code) async {
    final rows = await db.from('profiles').select('id,display_name,user_code').eq('user_code', code.trim().toUpperCase()).limit(1);
    return rows.isEmpty ? null : Map<String, dynamic>.from(rows.first);
  }
  Future<void> sendRequest(String targetId) async {
    if (targetId == uid) throw Exception('You cannot add yourself.');
    await db.from('friend_requests').insert({'sender_id': uid, 'receiver_id': targetId});
  }
  Future<void> respondRequest(String requestId, String status) async {
    await db.from('friend_requests').update({'status': status}).eq('id', requestId).eq('receiver_id', uid).eq('status', 'pending');
  }
  Future<List<Map<String, dynamic>>> chatPartners() async => friends();
  Future<List<Map<String, dynamic>>> messages(String otherId) async {
    final chatId = await _ensureChat(otherId);
    return List<Map<String, dynamic>>.from(await db.from('messages').select().eq('chat_id', chatId).order('created_at'));
  }
  Future<void> sendMessage(String otherId, String text) async {
    final clean = text.trim(); if (clean.isEmpty) return;
    final chatId = await _ensureChat(otherId);
    await db.from('messages').insert({'chat_id': chatId, 'sender_id': uid,
      'receiver_id': otherId, 'message_text': clean});
  }
  Stream<List<Map<String, dynamic>>> watchMessages(String otherId) =>
      db.from('messages').stream(primaryKey: ['id']).order('created_at').map((rows) =>
        rows.where((m) => (m['sender_id'] == uid && m['receiver_id'] == otherId) ||
          (m['sender_id'] == otherId && m['receiver_id'] == uid)).toList());
  Stream<List<Map<String, dynamic>>> watchRequests() =>
      db.from('friend_requests').stream(primaryKey: ['id']).eq('receiver_id', uid).map((rows) => rows.where((r) => r['status'] == 'pending').toList());
}
