import 'package:flutter/material.dart';
import 'chat_screen.dart';

class FriendDetailScreen extends StatelessWidget {
  final Map<String, dynamic> friend;
  const FriendDetailScreen({super.key, required this.friend});

  void _comingSoon(BuildContext context, String feature) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$feature ကို ချိတ်ဆက်ဖို့ calling service လိုအပ်နေသေးပါတယ်။')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final avatar = friend['avatar_url'] as String?;
    return Scaffold(
      appBar: AppBar(title: const Text('Friend profile')),
      body: ListView(padding: const EdgeInsets.all(24), children: [
        const SizedBox(height: 18),
        Center(child: CircleAvatar(radius: 54, backgroundImage: avatar == null || avatar.isEmpty ? null : NetworkImage(avatar), child: avatar == null || avatar.isEmpty ? const Icon(Icons.person, size: 56) : null)),
        const SizedBox(height: 16),
        Center(child: Text(friend['display_name'] ?? 'K’Cho user', style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold))),
        const SizedBox(height: 6),
        Center(child: Text(friend['user_code'] ?? '', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w600))),
        const SizedBox(height: 30),
        FilledButton.icon(
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(user: friend))),
          icon: const Icon(Icons.chat_bubble_outline), label: const Text('Message'),
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(onPressed: () => _comingSoon(context, 'Voice Call'), icon: const Icon(Icons.call), label: const Text('Voice Call')),
        const SizedBox(height: 10),
        OutlinedButton.icon(onPressed: () => _comingSoon(context, 'Video Call'), icon: const Icon(Icons.videocam_outlined), label: const Text('Video Call')),
      ]),
    );
  }
}
