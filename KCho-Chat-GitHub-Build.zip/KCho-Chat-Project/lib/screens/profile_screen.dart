import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import '../services/supabase_service.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  Map<String, dynamic>? _profile;
  bool _loading = true;
  bool _uploading = false;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    try {
      final profile = await SupabaseService.instance.myProfile();
      if (mounted) setState(() => _profile = profile);
    } catch (error) {
      if (mounted) _message('Could not load profile: $error');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _message(String value) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
  }

  Future<void> _pickPhoto() async {
    try {
      final file = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        imageQuality: 82,
        maxWidth: 1200,
      );
      if (file == null) return;
      setState(() => _uploading = true);
      final bytes = await file.readAsBytes();
      final extension = file.name.contains('.') ? file.name.split('.').last : 'jpg';
      final url = await SupabaseService.instance.uploadAvatar(bytes, extension);
      if (mounted) {
        setState(() => _profile = {...?_profile, 'avatar_url': url});
        _message('Profile photo updated.');
      }
    } catch (error) {
      if (mounted) _message('Photo upload failed: $error');
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  Future<void> _editName() async {
    final controller = TextEditingController(text: _profile?['display_name'] ?? '');
    final name = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit name'),
        content: TextField(
          controller: controller,
          autofocus: true,
          textCapitalization: TextCapitalization.words,
          maxLength: 40,
          decoration: const InputDecoration(labelText: 'Your name'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('Save')),
        ],
      ),
    );
    controller.dispose();
    if (name == null) return;
    setState(() => _saving = true);
    try {
      await SupabaseService.instance.updateDisplayName(name);
      await _loadProfile();
      if (mounted) _message('Name updated.');
    } catch (error) {
      if (mounted) _message('Could not update name: $error');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = SupabaseService.instance.db.auth.currentUser;
    final avatar = _profile?['avatar_url'] as String?;
    return RefreshIndicator(
      onRefresh: _loadProfile,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 28, 20, 32),
        children: [
          const Text('My Profile', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 28),
          Center(
            child: Stack(
              alignment: Alignment.bottomRight,
              children: [
                CircleAvatar(
                  radius: 58,
                  backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                  backgroundImage: avatar == null || avatar.isEmpty ? null : NetworkImage(avatar),
                  child: avatar == null || avatar.isEmpty
                      ? const Icon(Icons.person, size: 62)
                      : null,
                ),
                IconButton.filled(
                  onPressed: _uploading ? null : _pickPhoto,
                  tooltip: 'Change profile photo',
                  icon: _uploading
                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.camera_alt),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Center(
            child: Text(
              _profile?['display_name'] ?? 'K’Cho user',
              style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w600),
            ),
          ),
          const SizedBox(height: 24),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.person_outline),
                  title: const Text('Name'),
                  subtitle: Text(_profile?['display_name'] ?? 'Loading...'),
                  trailing: IconButton(icon: const Icon(Icons.edit_outlined), onPressed: _saving || _loading ? null : _editName),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.badge_outlined),
                  title: const Text('K’Cho ID'),
                  subtitle: Text(_profile?['user_code'] ?? (_loading ? 'Loading...' : 'Not assigned')),
                  trailing: IconButton(
                    tooltip: 'Copy K’Cho ID',
                    icon: const Icon(Icons.copy),
                    onPressed: (_profile?['user_code'] == null) ? null : () async {
                      await Clipboard.setData(ClipboardData(text: _profile!['user_code']));
                      if (mounted) _message('K’Cho ID copied.');
                    },
                  ),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.email_outlined),
                  title: const Text('Email'),
                  subtitle: Text(user?.email ?? 'No email'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          FilledButton.tonalIcon(
            onPressed: () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('Log out?'),
                  content: const Text('Do you want to sign out of K’Cho Chat?'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                    FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Log out')),
                  ],
                ),
              );
              if (confirm == true) await SupabaseService.instance.signOut();
            },
            icon: const Icon(Icons.logout),
            label: const Text('Log out'),
          ),
        ],
      ),
    );
  }
}
