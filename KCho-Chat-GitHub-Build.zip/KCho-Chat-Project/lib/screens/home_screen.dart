import 'dart:async';
import 'package:flutter/material.dart';
import '../services/supabase_service.dart';
import 'chat_screen.dart';
import 'friends_screen.dart';
import 'requests_screen.dart';
import 'profile_screen.dart';

class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState() => _HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  int _tab = 0; Map<String,dynamic>? _profile;
  Timer? _presenceTimer;
  @override void initState() { super.initState(); WidgetsBinding.instance.addObserver(this); _loadProfile(); _setOnline(true); _presenceTimer = Timer.periodic(const Duration(seconds: 30), (_) => _setOnline(true)); }
  Future<void> _setOnline(bool value) async { try { await SupabaseService.instance.updateMyPresence(value); } catch (_) {} }
  @override void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) { _setOnline(true); }
    if (state == AppLifecycleState.paused || state == AppLifecycleState.detached) { _setOnline(false); }
  }
  @override void dispose() { WidgetsBinding.instance.removeObserver(this); _presenceTimer?.cancel(); _setOnline(false); super.dispose(); }
  Future<void> _loadProfile() async { try { final p = await SupabaseService.instance.myProfile(); if (mounted) setState(() => _profile = p); } catch (_) {} }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text("K’Cho Chat", style: TextStyle(fontWeight: FontWeight.bold)), actions: [if (_profile != null) Padding(padding: const EdgeInsets.only(right: 8), child: Center(child: Text(_profile!['user_code'] ?? '', style: const TextStyle(fontWeight: FontWeight.w600))))]),
    body: IndexedStack(index: _tab, children: [const FriendsScreen(), const _ChatsScreen(), const RequestsScreen(), const ProfileScreen()]),
    bottomNavigationBar: NavigationBar(selectedIndex: _tab, onDestinationSelected: (i) => setState(() => _tab = i), destinations: const [NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'Friend'), NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Chat'), NavigationDestination(icon: Icon(Icons.person_add_alt), label: 'Request'), NavigationDestination(icon: Icon(Icons.account_circle_outlined), selectedIcon: Icon(Icons.account_circle), label: 'Profile')]),
  );
}
class _ChatsScreen extends StatefulWidget { const _ChatsScreen(); @override State<_ChatsScreen> createState() => _ChatsScreenState(); }
class _ChatsScreenState extends State<_ChatsScreen> {
  late Future<List<Map<String,dynamic>>> _future;
  @override void initState() { super.initState(); _future = SupabaseService.instance.chatPartners(); }
  void _refresh() => setState(() => _future = SupabaseService.instance.chatPartners());
  @override Widget build(BuildContext context) => RefreshIndicator(onRefresh: () async => _refresh(), child: FutureBuilder<List<Map<String,dynamic>>>(future: _future, builder: (context,s) {
    if (s.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
    if (s.hasError) return Center(child: Text('Could not load chats: ${s.error}'));
    final users = s.data ?? []; if (users.isEmpty) return ListView(children: const [SizedBox(height: 130), Icon(Icons.forum_outlined, size: 56, color: Colors.grey), SizedBox(height: 12), Center(child: Text('Your accepted friends will appear here.'))]);
    return ListView.separated(itemCount: users.length, separatorBuilder: (_,__) => const Divider(height: 1), itemBuilder: (context,i) { final u=users[i]; return ListTile(leading: const CircleAvatar(child: Icon(Icons.person)), title: Text(u['display_name'] ?? 'K’Cho user'), subtitle: Text(u['user_code'] ?? ''), trailing: const Icon(Icons.chevron_right), onTap: () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(user: u))); _refresh(); }); });
  }));
}
