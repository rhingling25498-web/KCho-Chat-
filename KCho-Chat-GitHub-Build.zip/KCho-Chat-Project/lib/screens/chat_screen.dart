import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'package:record/record.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import '../services/supabase_service.dart';

class ChatScreen extends StatefulWidget {
  final Map<String, dynamic> user;
  const ChatScreen({super.key, required this.user});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _text = TextEditingController();
  final _scroll = ScrollController();
  bool _sending = false;
  bool _recording = false;
  final AudioRecorder _recorder = AudioRecorder();
  Timer? _typingTimer;
  bool _typingSent = false;
  String get _other => widget.user['id'] as String;

  @override
  void dispose() { _typingTimer?.cancel(); if (_typingSent) { SupabaseService.instance.updateTyping(_other, false); } _text.dispose(); _scroll.dispose(); _recorder.dispose(); super.dispose(); }

  void _onTextChanged(String value) {
    if (value.trim().isEmpty) { _typingTimer?.cancel(); if (_typingSent) { _typingSent = false; SupabaseService.instance.updateTyping(_other, false); } return; }
    if (!_typingSent) { _typingSent = true; SupabaseService.instance.updateTyping(_other, true); }
    _typingTimer?.cancel();
    _typingTimer = Timer(const Duration(seconds: 2), () { _typingSent = false; SupabaseService.instance.updateTyping(_other, false); });
  }

  void _toast(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  Future<void> _send() async {
    final body = _text.text.trim();
    if (body.isEmpty || _sending) return;
    setState(() => _sending = true);
    _text.clear();
    _typingTimer?.cancel(); _typingSent = false; SupabaseService.instance.updateTyping(_other, false);
    try { await SupabaseService.instance.sendMessage(_other, body); }
    catch (e) { if (mounted) { _text.text = body; _toast('Message failed: $e'); } }
    if (mounted) setState(() => _sending = false);
  }

  Future<void> _sendMedia({required bool video}) async {
    if (_sending) return;
    try {
      final picker = ImagePicker();
      final file = video
          ? await picker.pickVideo(source: ImageSource.gallery, maxDuration: const Duration(minutes: 3))
          : await picker.pickImage(source: ImageSource.gallery, imageQuality: 85, maxWidth: 1600);
      if (file == null) return;
      setState(() => _sending = true);
      final bytes = await file.readAsBytes();
      final ext = file.name.contains('.') ? file.name.split('.').last.toLowerCase() : (video ? 'mp4' : 'jpg');
      final type = video ? 'video/$ext' : (ext == 'png' ? 'image/png' : 'image/jpeg');
      final url = await SupabaseService.instance.uploadChatMedia(bytes, ext, contentType: type);
      await SupabaseService.instance.sendMediaMessage(_other, url, video ? 'video' : 'image');
    } catch (e) {
      if (mounted) _toast('Media ပို့မရပါ: $e');
    } finally { if (mounted) setState(() => _sending = false); }
  }

  Future<void> _toggleVoiceRecording() async {
    if (_sending) return;
    try {
      if (!_recording) {
        final allowed = await _recorder.hasPermission();
        if (!allowed) { _toast('Microphone permission မရပါ။ Settings မှာ ခွင့်ပြုပေးပါ။'); return; }
        final dir = await getTemporaryDirectory();
        final path = '${dir.path}/kcho_voice_${DateTime.now().millisecondsSinceEpoch}.m4a';
        await _recorder.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: path);
        if (mounted) setState(() => _recording = true);
      } else {
        final path = await _recorder.stop();
        if (mounted) setState(() { _recording = false; _sending = true; });
        if (path == null) return;
        final file = File(path);
        final bytes = await file.readAsBytes();
        final url = await SupabaseService.instance.uploadChatMedia(bytes, 'm4a', contentType: 'audio/mp4');
        await SupabaseService.instance.sendVoiceMessage(_other, url);
        await file.delete();
      }
    } catch (e) {
      if (mounted) { setState(() => _recording = false); _toast('အသံစာပို့မရပါ: $e'); }
    } finally { if (mounted) setState(() => _sending = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(widget.user['display_name'] ?? 'Chat'),
      StreamBuilder<List<Map<String, dynamic>>>(stream: SupabaseService.instance.watchTyping(_other), builder: (context, typing) {
        final isTyping = typing.data?.any((row) => row['is_typing'] == true) ?? false;
        if (isTyping) return const Text('စာရိုက်နေသည်...', style: TextStyle(fontSize: 12, color: Colors.green));
        return StreamBuilder<List<Map<String, dynamic>>>(stream: SupabaseService.instance.watchPresence(_other), builder: (context, presence) {
          final row = presence.data?.isNotEmpty == true ? presence.data!.first : null;
          final seenAt = DateTime.tryParse((row?['last_seen'] ?? '').toString());
          final fresh = seenAt != null && DateTime.now().toUtc().difference(seenAt.toUtc()).inSeconds < 90;
          final online = row?['is_online'] == true && fresh;
          return Text(online ? 'Online · ${widget.user['user_code'] ?? ''}' : 'Offline · ${widget.user['user_code'] ?? ''}', style: TextStyle(fontSize: 12, color: online ? Colors.green : Colors.black54));
        });
      }),
    ])),
    body: Column(children: [
      Expanded(child: StreamBuilder<List<Map<String, dynamic>>>(
        stream: SupabaseService.instance.watchMessages(_other),
        builder: (context, s) {
          if (s.hasError) return Center(child: Text('Chat error: ${s.error}'));
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final rows = s.data!;
          SupabaseService.instance.markMessagesRead(_other).catchError((_) {});
          if (rows.isEmpty) return const Center(child: Text('Say hello to start chatting!'));
          WidgetsBinding.instance.addPostFrameCallback((_) { if (_scroll.hasClients) _scroll.jumpTo(_scroll.position.maxScrollExtent); });
          return ListView.builder(controller: _scroll, padding: const EdgeInsets.all(12), itemCount: rows.length, itemBuilder: (context, i) {
            final m = rows[i]; final mine = m['sender_id'] == SupabaseService.instance.uid;
            final time = DateTime.tryParse(m['created_at'] ?? '')?.toLocal();
            final mediaType = m['media_type']; final mediaUrl = m['media_url'] as String?;
            return Align(alignment: mine ? Alignment.centerRight : Alignment.centerLeft, child: Container(
              constraints: const BoxConstraints(maxWidth: 300), margin: const EdgeInsets.symmetric(vertical: 4),
              padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: mine ? const Color(0xFF3867D6) : Colors.white, borderRadius: BorderRadius.circular(16)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                if (mediaUrl != null && mediaType != null) _PrivateChatMedia(path: mediaUrl, type: mediaType, mine: mine),
                if ((m['message_text'] ?? '').toString().isNotEmpty && !['Photo','Video','Voice message'].contains(m['message_text'])) Align(alignment: Alignment.centerLeft, child: Text(m['message_text'], style: TextStyle(color: mine ? Colors.white : Colors.black87, fontSize: 16))),
                Row(mainAxisSize: MainAxisSize.min, children: [
                  if (time != null) Text(DateFormat('h:mm a').format(time), style: TextStyle(fontSize: 10, color: mine ? Colors.white70 : Colors.black45)),
                  if (mine && m['read_at'] != null) const Padding(padding: EdgeInsets.only(left: 4), child: Icon(Icons.done_all, size: 14, color: Colors.lightBlueAccent)),
                ]),
              ]),
            ));
          });
        },
      )),
      SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(8, 6, 8, 10), child: Row(children: [
        IconButton(tooltip: 'Send photo', onPressed: _sending ? null : () => _sendMedia(video: false), icon: const Icon(Icons.image_outlined)),
        IconButton(tooltip: 'Send video', onPressed: _sending ? null : () => _sendMedia(video: true), icon: const Icon(Icons.video_library_outlined)),
        IconButton(tooltip: _recording ? 'Stop and send voice message' : 'Record voice message', onPressed: _sending ? null : _toggleVoiceRecording, icon: Icon(_recording ? Icons.stop_circle : Icons.mic, color: _recording ? Colors.red : null)),
        Expanded(child: TextField(controller: _text, onChanged: _onTextChanged, minLines: 1, maxLines: 4, textInputAction: TextInputAction.newline, decoration: InputDecoration(hintText: 'Message...', filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none), contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12)))),
        const SizedBox(width: 6),
        IconButton.filled(onPressed: _sending ? null : _send, icon: _sending ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.send)),
      ]))),
    ]),
  );
}


class _ChatVideo extends StatefulWidget {
  final String url;
  const _ChatVideo({required this.url});
  @override
  State<_ChatVideo> createState() => _ChatVideoState();
}

class _ChatVideoState extends State<_ChatVideo> {
  late final VideoPlayerController _controller;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
      ..initialize().then((_) {
        if (mounted) setState(() {});
      }).catchError((_) {
        if (mounted) setState(() => _failed = true);
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_failed) return const Text('Video ကိုဖွင့်မရပါ။');
    if (!_controller.value.isInitialized) {
      return const SizedBox(width: 230, height: 130, child: Center(child: CircularProgressIndicator()));
    }
    return SizedBox(
      width: 250,
      child: Column(children: [
        AspectRatio(
          aspectRatio: _controller.value.aspectRatio,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: VideoPlayer(_controller),
          ),
        ),
        IconButton(
          onPressed: () => setState(() {
            _controller.value.isPlaying ? _controller.pause() : _controller.play();
          }),
          icon: Icon(_controller.value.isPlaying ? Icons.pause_circle : Icons.play_circle, size: 34),
        ),
      ]),
    );
  }
}


class _VoiceMessage extends StatefulWidget {
  final String url;
  final bool mine;
  const _VoiceMessage({required this.url, required this.mine});
  @override
  State<_VoiceMessage> createState() => _VoiceMessageState();
}

class _VoiceMessageState extends State<_VoiceMessage> {
  late final AudioPlayer _player;
  bool _loading = false;
  bool _failed = false;
  @override
  void initState() { super.initState(); _player = AudioPlayer(); }
  @override
  void dispose() { _player.dispose(); super.dispose(); }
  Future<void> _toggle() async {
    try {
      if (_player.playing) { await _player.pause(); }
      else {
        if (_player.audioSource == null) {
          setState(() => _loading = true);
          await _player.setUrl(widget.url);
          if (mounted) setState(() => _loading = false);
        }
        await _player.play();
      }
    } catch (_) { if (mounted) setState(() { _failed = true; _loading = false; }); }
  }
  @override
  Widget build(BuildContext context) => StreamBuilder<PlayerState>(
    stream: _player.playerStateStream,
    builder: (context, snapshot) {
      final playing = snapshot.data?.playing ?? false;
      return SizedBox(width: 210, child: Row(children: [
        IconButton(onPressed: _failed || _loading ? null : _toggle, icon: _loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : Icon(playing ? Icons.pause_circle : Icons.play_circle, size: 32, color: widget.mine ? Colors.white : null)),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Text(_failed ? 'အသံဖွင့်မရပါ' : 'Voice message', style: TextStyle(color: widget.mine ? Colors.white : Colors.black87)),
          StreamBuilder<Duration?>(stream: _player.durationStream, builder: (_, d) => Text(d.data == null ? 'အသံစာ' : '${d.data!.inMinutes}:${(d.data!.inSeconds % 60).toString().padLeft(2, '0')}', style: TextStyle(fontSize: 11, color: widget.mine ? Colors.white70 : Colors.black54))),
        ])),
      ]));
    },
  );
}


class _PrivateChatMedia extends StatelessWidget {
  final String path; final String type; final bool mine;
  const _PrivateChatMedia({required this.path, required this.type, required this.mine});
  @override
  Widget build(BuildContext context) => FutureBuilder<String>(
    future: SupabaseService.instance.chatMediaSignedUrl(path),
    builder: (context, snapshot) {
      if (!snapshot.hasData) return const SizedBox(width: 220, height: 90, child: Center(child: CircularProgressIndicator()));
      final url = snapshot.data!;
      if (type == 'image') return ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.network(url, width: 240, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Text('Image unavailable')));
      if (type == 'video') return _ChatVideo(url: url);
      if (type == 'voice') return _VoiceMessage(url: url, mine: mine);
      return const Text('Unsupported attachment');
    },
  );
}
